angular.module('app').run(['$templateCache', function($templateCache) {
  'use strict';

  $templateCache.put('directives/listing',
    "<div class=\"listing mui--z1\" ui-sref=\"item({itemId: listing._id})\"><img ng-src={{listing.images[0].external}} alt=\"\"><div class=title>{{listing.name | limitTo:20 }}<condition>{{listing.condition }}</condition><span class=commentCount>{{listing.comments.length}} <i class=material-icons>comment</i></span></div><p class=content>{{ listing.description | limitTo:80 }}...</p></div>"
  );


  $templateCache.put('feed/feed',
    "<div ng-controller=feedController><div infinite-scroll=moreProducts() infinite-scroll-distance=3><secondary-nav>Recent Listings</secondary-nav><listing ng-repeat=\"listing in listings\" listing=listing></listing><div ng-show=loading><div class=sk-three-bounce><div class=\"sk-child sk-bounce1\"></div><div class=\"sk-child sk-bounce2\"></div><div class=\"sk-child sk-bounce3\"></div></div></div></div></div>"
  );


  $templateCache.put('item/item',
    "<div class=item ng-controller=itemController><div ng-show=loading class=loading><b>Loading Item</b><div class=sk-three-bounce><div class=\"sk-child sk-bounce1\"></div><div class=\"sk-child sk-bounce2\"></div><div class=\"sk-child sk-bounce3\"></div></div></div><div ng-hide=loading><img ng-src={{item.images[0].external}} alt=\"\"><div class=title>{{item.name}} <i class=\"material-icons false\" ng-click=add() ng-show=\"$auth.user.wishlist.indexOf(item._id) == -1\">star_border</i> <i ng-click=remove() ng-hide=\"$auth.user.wishlist.indexOf(item._id) == -1\" class=\"material-icons true\">star</i></div><div class=condition>{{item.condition}} Condition</div><div class=price>{{item.price | currency:\"$\"}}</div><div class=\"discription mui--z2\">{{item.description}}</div><div class=comments><div class=commentHeader>Comments</div><comment ng-repeat=\"comment in item.comments\"><b>{{comment.username}}</b> {{comment.comment}}</comment><div class=center ng-hide=$auth.user._id><button ui-sref=login class=\"mui-btn mui-btn--raised mui-btn--primary\">Login to Comment</button></div><form ng-submit=createComment(comment) ng-show=$auth.user._id><div class=mui-textfield><input ng-model=comment rows=0 placeholder=\"New Comment\"></div></form></div></div></div>"
  );


  $templateCache.put('login/login',
    "<div class=login ng-controller=loginController><secondary-nav>Login To Your Account</secondary-nav><mui-panel style=\"margin: 0\"><div class=icon-container><i class=material-icons>account_circle</i><p>If you don't have an account you can register <a ui-sref=register>here<a></a></a></p></div><div class=error ng-show=error>{{error}}</div><form ng-submit=\"login(username, password)\"><div class=\"mui-textfield mui-textfield--float-label\"><input ng-model=username autocapitalize=off float-label label=Username required><label>Username</label></div><div class=\"mui-textfield mui-textfield--float-label\"><input ng-model=password autocapitalize=off float-label label=Password required><label>Password</label></div><div class=center><button class=\"mui-btn mui-btn--primary\" type=submit>Login</button></div></form></mui-panel></div>"
  );


  $templateCache.put('navigation/nav',
    "<top-bar></top-bar><primary-nav><i class=\"material-icons left\" ng-click=toggleNav()>menu</i><div class=brand><low>thrift</low>Fund</div><i ui-sref=home ng-show=\"$state.current.name == 'new' || $state.current.name == 'item'\" class=\"material-icons right\">list</i> <i ui-sref=new ng-show=\"$state.current.name != 'new' && $state.current.name != 'item'\" class=\"material-icons right\">add_circle</i></primary-nav><primary-nav-fill></primary-nav-fill><nav-overlay class=\"animated fadeInDownBig\" ng-show=showNav ng-click=toggleNav()><div class=brand-container><div class=brand><low>thrift</low>Fund</div></div><item ui-sref=home>Listings</item><item ui-sref=new>Donate</item><item ui-sref=register ng-hide=$auth.user._id>Register</item><item ui-sref=login ng-hide=$auth.user._id>Login</item><item ui-sref=wishlist ng-show=$auth.user._id>Wishlist</item><item ng-click=$auth.logout() ng-show=$auth.user._id>Logout</item><user-nav ng-show=$auth.user._id><username>{{$auth.user.username}}</username><name>{{$auth.user.name.first}} {{$auth.user.name.last}}</name></user-nav></nav-overlay><div ui-view class=mainContent></div><footer><div class=brand><low>thrift</low>Fund</div></footer>"
  );


  $templateCache.put('new/new',
    "<div ng-controller=newController class=createItem><secondary-nav>Donate An Item</secondary-nav><div ng-if=!$auth.user._id><mui-panel style=\"margin: 0\"><div class=new-unauthed><i class=material-icons>add_shopping_cart</i><p>You must login or register a new account to donate an item.</p><button class=\"mui-btn mui-btn--raised mui-btn--primary\" ui-sref=login>Login</button> <button class=\"mui-btn mui-btn--raised\" ui-sref=register>register</button></div></mui-panel></div><div ng-show=loading class=loading><b>Creating Donation</b><div class=sk-three-bounce><div class=\"sk-child sk-bounce1\"></div><div class=\"sk-child sk-bounce2\"></div><div class=\"sk-child sk-bounce3\"></div></div></div><div ng-if=$auth.user._id ng-hide=loading><div class=\"picturePlaceholder needsclick\" ng-click=initUpload() ng-hide=file><i class=\"material-icons needsclick\">add_a_photo</i> <input type=file id=fileInput fileread=file init=LoadCrop class=\"offscreen needsclick\"></div><div class=picturePlaceholder ng-show=file><img id=image ng-src={{file}} alt=\"\"></div><mui-panel style=\"margin: 0\"><form><mui-input ng-model=item.name float-label label=\"Item Name\"></mui-input><div class=\"mui-textfield mui-textfield--float-label\"><input type=number step=any pattern=[0-9]* ng-model=item.price><label>Price</label></div><mui-select ng-model=item.condition name=inputA float-label label=\"Item Condition\" use-default><mui-option value=\"Like New\" label=\"Like New\"></mui-option><mui-option value=\"Gently Used\" label=\"Gently Used\"></mui-option><mui-option value=Used label=Used></mui-option><mui-option value=\"Very Used\" label=\"Very Used\"></mui-option></mui-select><mui-textarea ng-model=item.description rows=5 float-label label=\"Item Discription\"></mui-textarea><div class=center><button class=\"mui-btn mui-btn--primary\" ng-click=submit(item)>Submit</button></div></form></mui-panel></div></div>"
  );


  $templateCache.put('register/register',
    "<div ng-controller=registerController class=register><secondary-nav>Register An Account</secondary-nav><mui-panel style=\"margin: 0\"><div class=icon-container><i class=material-icons>account_circle</i><p>Registering allows you to comment, post, and favorite items.</p></div><div class=error ng-show=error>{{error}}</div><form ng-submit=register(user)><mui-input ng-model=user.name.first float-label label=\"First Name\" required></mui-input><mui-input ng-model=user.name.last float-label label=\"Last Name\" required></mui-input><div class=\"mui-textfield mui-textfield--float-label\"><input ng-model=user.username autocapitalize=off float-label label=Username required><label>Username</label></div><div class=\"mui-textfield mui-textfield--float-label\"><input ng-model=user.password autocapitalize=off float-label label=Password required><label>Password</label></div><div class=center><mui-button type=submit color=primary variant=raised>Register</mui-button></div></form></mui-panel></div>"
  );


  $templateCache.put('wishlist/wishlist',
    "<div ng-controller=wishlistController><div><secondary-nav>Wishlist</secondary-nav><user-nav ng-show=$auth.user._id><username>{{$auth.user.username}}</username><name>{{$auth.user.name.first}} {{$auth.user.name.last}}</name></user-nav><div ng-show=loading class=loading><b>Loading Wishlist</b><div class=sk-three-bounce><div class=\"sk-child sk-bounce1\"></div><div class=\"sk-child sk-bounce2\"></div><div class=\"sk-child sk-bounce3\"></div></div></div><div ng-repeat=\"listing in listings\" ng-hide=loading><div class=\"wishlist mui--z1\" ui-sref=\"item({itemId: listing._id})\"><div class=title>{{listing.name | limitTo:20 }}<condition>{{listing.condition }}</condition></div><p class=content>{{ listing.description | limitTo:80 }}...</p></div></div><br><br><br><br></div></div>"
  );

}]);
